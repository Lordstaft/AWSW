<?php
namespace es\ucm\fdi\aw\usuarios;

use es\ucm\fdi\aw\Formulario;
use es\ucm\fdi\aw\Aplicacion;

class FormularioLogin extends Formulario
{

    public function __construct() {
        parent::__construct('formLogin', [
            'action' => Aplicacion::getInstance()->resuelve('/login.php'),
            'urlRedireccion' => Aplicacion::getInstance()->resuelve('/inicio.php')
        ]);
    }

    protected function generaCamposFormulario(&$datos)
    {
        $nombreUsuario = $datos['nombreUsuario'] ?? '';
        $password = $datos['password'] ?? '';

        $html = <<<EOS
        <fieldset>
            <legend>Login</legend>
            <div>
                <label for="nombreUsuario">Nombre de usuario:</label>
                <input id="nombreUsuario" type="text" name="nombreUsuario" value="$nombreUsuario" />
            </div>
            <div>
                <label for="password">Contraseña:</label>
                <input id="password" type="password" name="password" value="$password" />
            </div>
            <div>
                <button type="submit" name="login">Entrar</button>
            </div>
        </fieldset>
        EOS;

        return $html;
    }

    protected function procesaFormulario(&$datos)
    {
        $this->errores = [];

        $nombreUsuario = trim($datos['nombreUsuario'] ?? '');
        $password = trim($datos['password'] ?? '');

        if ($nombreUsuario === '') {
            $this->errores['nombreUsuario'] = 'El nombre de usuario no puede estar vacío';
        }

        if ($password === '') {
            $this->errores['password'] = 'La contraseña no puede estar vacía';
        }

        if (count($this->errores) === 0) {
            $usuario = Usuario::login($nombreUsuario, $password);

            if (!$usuario) {
                $this->errores[] = "El usuario o el password no coinciden";
            }
            else {
                $app = Aplicacion::getInstance();
                $app->login($usuario);
                $app->redirige('/inicio.php');
            }
        }
    }
}
